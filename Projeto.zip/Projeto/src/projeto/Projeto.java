/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package projeto;

import DAO.pessoaDAO;
import static java.time.Clock.system;
import static java.time.InstantSource.system;
import java.time.LocalDate;




import java.util.Scanner;

/**
 *
 * @author Matheus
 */
public class Projeto {

    
    
    
    
    
    
    
    
    
    public static void main(String[] args) {
        // TODO code application logic here

        /*LocalDate dataNascimento = LocalDate.of(1999, 12,9 ); // Substitua com a data de nascimento desejada
        Pessoa pessoa = new Pessoa(1, "Matheus De Melo", "Masculino", dataNascimento, "matheusdmsh", "senha123", "Admin");
        System.out.println(pessoa);*/
        
        new pessoaDAO();
        
        
        
        
        
        
        
        

    }

}
