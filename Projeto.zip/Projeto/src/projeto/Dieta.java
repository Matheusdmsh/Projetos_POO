/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package projeto;

import java.time.LocalDate;
import java.util.Objects;
import projeto.TipoDieta;
import projeto.Pessoa;
import projeto.AvaliacaoFisica;







/**
 *
 * @author Matheus
 */
public class Dieta {
    
    private long id;
    private static long serial;
    private Pessoa pessoa; 
    private AvaliacaoFisica AF;
    private TipoDieta tipoDieta;
    private String objetivo;
    private double calorias;
    private int nroRefeicao;
    private LocalDate dataCriacao;
    private LocalDate dataModificacao;

    public Dieta() {
        id = Dieta.serial++;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public static long getSerial() {
        return serial;
    }

    public static void setSerial(long serial) {
        Dieta.serial = serial;
    }

    public Pessoa getPessoa() {
        return pessoa;
    }

    public void setPessoa(Pessoa pessoa) {
        this.pessoa = pessoa;
    }

    public AvaliacaoFisica getAF() {
        return AF;
    }

    public void setAF(AvaliacaoFisica AF) {
        this.AF = AF;
    }

    public TipoDieta getTipoDieta() {
        return tipoDieta;
    }

    public void setTipoDieta(TipoDieta tipoDieta) {
        this.tipoDieta = tipoDieta;
    }

    public String getObjetivo() {
        return objetivo;
    }

    public void setObjetivo(String objetivo) {
        this.objetivo = objetivo;
    }

    public double getCalorias() {
        return calorias;
    }

    public void setCalorias(double calorias) {
        this.calorias = calorias;
    }

    public int getNroRefeicao() {
        return nroRefeicao;
    }

    public void setNroRefeicao(int nroRefeicao) {
        this.nroRefeicao = nroRefeicao;
    }

    public LocalDate getDataCriacao() {
        return dataCriacao;
    }

    public void setDataCriacao(LocalDate dataCriacao) {
        this.dataCriacao = dataCriacao;
    }

    public LocalDate getDataModificacao() {
        return dataModificacao;
    }

    public void setDataModificacao(LocalDate dataModificacao) {
        this.dataModificacao = dataModificacao;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 89 * hash + (int) (this.id ^ (this.id >>> 32));
        hash = 89 * hash + Objects.hashCode(this.pessoa);
        hash = 89 * hash + Objects.hashCode(this.AF);
        hash = 89 * hash + Objects.hashCode(this.tipoDieta);
        hash = 89 * hash + Objects.hashCode(this.objetivo);
        hash = 89 * hash + (int) (Double.doubleToLongBits(this.calorias) ^ (Double.doubleToLongBits(this.calorias) >>> 32));
        hash = 89 * hash + this.nroRefeicao;
        hash = 89 * hash + Objects.hashCode(this.dataCriacao);
        hash = 89 * hash + Objects.hashCode(this.dataModificacao);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Dieta other = (Dieta) obj;
        if (this.id != other.id) {
            return false;
        }
        if (Double.doubleToLongBits(this.calorias) != Double.doubleToLongBits(other.calorias)) {
            return false;
        }
        if (this.nroRefeicao != other.nroRefeicao) {
            return false;
        }
        if (!Objects.equals(this.objetivo, other.objetivo)) {
            return false;
        }
        if (!Objects.equals(this.pessoa, other.pessoa)) {
            return false;
        }
        if (!Objects.equals(this.AF, other.AF)) {
            return false;
        }
        if (!Objects.equals(this.tipoDieta, other.tipoDieta)) {
            return false;
        }
        if (!Objects.equals(this.dataCriacao, other.dataCriacao)) {
            return false;
        }
        return Objects.equals(this.dataModificacao, other.dataModificacao);
    }

    @Override
    public String toString() {
        return "Dieta: " + "\n" 
                + "......................................." + "\n"
                + "id...: " + id + "\n" 
                + "pessoa...: " + pessoa + "\n"
                + "AF...: " + AF + "\n" 
                + "tipoDieta...: " + tipoDieta + "\n"
                + "objetivo...: " + objetivo + "\n"
                + "calorias...: " + calorias + "\n"
                + "nroRefeicao...: " + nroRefeicao + "\n" 
                + "dataCriacao...: " + dataCriacao + "\n"
                + "dataModificacao...: " + dataModificacao + "\n"
                + "......................................." + "\n";
    }
    
    
    
    
}
