/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;
import java.time.LocalDate;
import projeto.Dieta;
import projeto.Refeicao;

/**
 *
 * @author Matheus
 */
public class refeicaoDAO {
    
    
    private refeicaoDAO [] refeicoes = new refeicaoDAO[25];
    private int count;

    public refeicaoDAO() {
        refeicoes = new refeicaoDAO[25];
        count = 0;
    }
    
    
    
    public void criarRefeicao(Dieta dieta, String nomeRefeicao, double proteina) {
        if (count < refeicoes.length) {
            Refeicao novaRefeicao = new Refeicao();
            novaRefeicao.setDieta(dieta);
            novaRefeicao.setNomeRefeicao(nomeRefeicao);
            novaRefeicao.setProteina(proteina);
           
            // Calcula as calorias com base na dieta e no tipo de refeição
            double calorias = calcularCaloriasRefeicao(dieta, tipoRefeicao);
            novaRefeicao.setCalorias(calorias);

            novaRefeicao.setDataCriacao(LocalDate.now());

            
            count++;
        } else {
            System.out.println("Capacidade máxima atingida. Não é possível adicionar mais refeições.");
        }
    }

    // Método para calcular as calorias da refeição com base na dieta e no tipo de refeição
    private double calcularCaloriasRefeicao(Dieta dieta, String tipoRefeicao) {
        double caloriasDieta = dieta.getCalorias();
        int numeroRefeicoes = dieta.getNroRefeicao();

        // Caso queria dividir por igual, calorias pela quantidade de refeição
        double caloriasPorRefeicao = caloriasDieta / numeroRefeicoes;

        if (tipoRefeicao.equalsIgnoreCase("café da manhã")) {
            return caloriasPorRefeicao * 0.20; 
        } else if (tipoRefeicao.equalsIgnoreCase("almoço")) {
            return caloriasPorRefeicao * 0.40; 
        } else if (tipoRefeicao.equalsIgnoreCase("lanche")) {
            return caloriasPorRefeicao * 0.20;
        } else if (tipoRefeicao.equalsIgnoreCase("janta")) {
            return caloriasPorRefeicao * 0.20; 
        } else {
           
            return caloriasPorRefeicao;
        }
    }
    
}
