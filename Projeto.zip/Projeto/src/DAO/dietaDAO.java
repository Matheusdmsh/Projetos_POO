/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import java.time.LocalDate;
import java.util.Scanner;


import projeto.TipoDieta;
import projeto.Dieta;
import projeto.AvaliacaoFisica;
import projeto.Pessoa;

/**
 *
 * @author Matheus
 */
public class dietaDAO {

    private Dieta[] dietas = new Dieta[30];
    private int count;
    //Scanner scanner = new Scanner(System.in);



    public dietaDAO() {
        count = 0;
    }

    // Método para criar uma nova dieta
    public void criarDieta(Pessoa pessoa, TipoDieta tipoDieta, AvaliacaoFisica AF, String objetivo, int numeroRefeicoes) {
        if (count < dietas.length) {
            Dieta novaDieta = new Dieta();
            novaDieta.setPessoa(pessoa);
            novaDieta.setTipoDieta(tipoDieta);
            novaDieta.setAF(AF);
            novaDieta.setObjetivo(objetivo);
            novaDieta.setNroRefeicao(numeroRefeicoes);
            novaDieta.setDataCriacao(LocalDate.now());

            // Calcula as calorias com base nas informações
            double calorias = calcularCalorias(pessoa, objetivo, AF);
            novaDieta.setCalorias(calorias);

            dietas[count] = novaDieta;
            count++;
        } else {
            System.out.println("Capacidade máxima atingida. Não é possível adicionar mais dietas.");
        }
    }

    // Método para ler uma dieta com base no ID
    public Dieta lerDieta(long id) {
        for (int i = 0; i < count; i++) {
            if (dietas[i].getId() == id) {
                return dietas[i];
            }
        }
        return null; // Retorna null se a dieta não for encontrada
    }

    // Método para atualizar os dados de uma dieta
    public boolean atualizarDieta(long id, Dieta novaDieta) {
        for (int i = 0; i < count; i++) {
            if (dietas[i].getId() == id) {
                // Atualiza os dados da dieta com os novos dados
                dietas[i] = novaDieta;
                dietas[i].setDataModificacao(LocalDate.now());

                return true; // Retorna verdadeiro se a atualização for bem-sucedida
            }
        }
        return false; // Retorna falso se a dieta com o ID especificado não for encontrada
    }

    // Método para excluir uma dieta com base no ID
    public boolean excluirDieta(long id) {
        for (int i = 0; i < count; i++) {
            if (dietas[i].getId() == id) {
                // Move todas as dietas posteriores uma posição para frente
                for (int j = i; j < count - 1; j++) {
                    dietas[j] = dietas[j + 1];
                }
                count--;

                // Define a última posição como nula
                dietas[count] = null;

                return true; // Retorna verdadeiro se a exclusão for bem-sucedida
            }
        }
        return false; // Retorna falso se a dieta com o ID especificado não for encontrada
    }

    // Método para calcular as calorias com base no TMB e objetivo
    private double calcularCalorias(Pessoa pessoa, String objetivo, AvaliacaoFisica AF) {
        double tmb = AF.getTmb();
        double calorias = tmb;

        if (objetivo.equals("DIMINUIR O PESO")) {
            calorias -= 500; // Reduzir 500 calorias
        } else if (objetivo.equals("MANTER O PESO")) {
            // Manter o mesmo número de calorias do TMB
        } else if (objetivo.equals("AUMENTAR O PESO")) {
            calorias += 500; // Aumentar 500 calorias
        } 

        return calorias;
    }
    
    
    
}
