/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import projeto.TipoDieta;
import java.util.Scanner;
import java.time.LocalDate;

/**
 *
 * @author Matheus
 */
public class tipoDietaDAO {
    
    private TipoDieta[] dietas;
    private int nextId;

    public tipoDietaDAO(int size) {
        dietas = new TipoDieta[size];
        nextId = 0; // Inicializamos com 0, uma vez que vamos usar nextId como índice do vetor
    }

    public void criarDieta(TipoDieta dieta) {
        if (nextId < dietas.length) {
            dietas[nextId] = dieta;
            nextId++;
        } else {
            System.out.println("Limite de dietas alcançado.");
        }
    }

    public TipoDieta lerDieta(long id) {
        for (TipoDieta dieta : dietas) {
            if (dieta != null && dieta.getId() == id) {
                return dieta;
            }
        }
        return null;
    }

    public void atualizarDieta(long id, TipoDieta novaDieta) {
        for (int i = 0; i < nextId; i++) {
            if (dietas[i] != null && dietas[i].getId() == id) {
                dietas[i] = novaDieta;
                return;
            }
        }
        System.out.println("Dieta não encontrada.");
    }

    public void excluirDieta(long id) {
        for (int i = 0; i < nextId; i++) {
            if (dietas[i] != null && dietas[i].getId() == id) {
                dietas[i] = null;
                compactarVetor(); // Compacta o vetor após excluir
                System.out.println("Dieta excluída com sucesso.");
                return;
            }
        }
        System.out.println("Dieta não encontrada.");
    }

    public void compactarVetor() {
        int index = 0;
        for (int i = 0; i < nextId; i++) {
            if (dietas[i] != null) {
                dietas[index] = dietas[i];
                index++;
            }
        }
        nextId = index;
    }

    public TipoDieta[] listarDietas() {
        TipoDieta[] dietasListadas = new TipoDieta[nextId];
        System.arraycopy(dietas, 0, dietasListadas, 0, nextId);
        return dietasListadas;
    }

    public void calcularNutrientesBaseadoEmDieta(long id, String tipoDieta) {
        TipoDieta dietaExistente = lerDieta(id);

        if (dietaExistente != null) {
            double calorias = dietaExistente.getKcal();
            double[] distribuicao = new double[3];

            switch (tipoDieta) {
                case "EQUILIBRADA":
                    distribuicao[0] = (0.4 * calorias) / 4; // Carboidrato
                    distribuicao[1] = (0.3 * calorias) / 4; // Proteína
                    distribuicao[2] = (0.3 * calorias) / 4; // Gordura
                    break;
                case "LOW CARB":
                    distribuicao[0] = (0.3 * calorias) / 4; // Carboidrato
                    distribuicao[1] = (0.5 * calorias) / 4; // Proteína
                    distribuicao[2] = (0.2 * calorias) / 4; // Gordura
                    break;
                case "CETOGENICA":
                    distribuicao[0] = (0.15 * calorias) / 4; // Carboidrato
                    distribuicao[1] = (0.15 * calorias) / 4; // Proteína
                    distribuicao[2] = (0.7 * calorias) / 4;  // Gordura
                    break;
                default:
                    System.out.println("Tipo de dieta não reconhecido.");
                    return;
            }

            System.out.println("RESULTADO:");
            System.out.println("Nome: " + dietaExistente.getNome());
            System.out.println("Kcal: " + calorias);
            System.out.println("Tipo de Dieta: " + tipoDieta);
            System.out.println("Quantidade de Carboidrato: " + distribuicao[0] + "g");
            System.out.println("Quantidade de Proteína: " + distribuicao[1] + "g");
            System.out.println("Quantidade de Gordura: " + distribuicao[2] + "g");
        } else {
            System.out.println("Dieta não encontrada.");
        }
    }    
    
}
